function handleSubmit () {
    const email = document.getElementById('email').value;
    localStorage.setItem("email",email);
    return;
    
}